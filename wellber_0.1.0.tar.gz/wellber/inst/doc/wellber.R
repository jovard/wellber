## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo=FALSE, out.width = "690px"------------------------------------
knitr::include_graphics("/Users/jvard/Documents/MSc Data Analytics/Year_3/Adv Data Prog with R (STAT40830)/Wk_11/wellber/vignettes/wellber_app_screen.png")

## ---- warning=FALSE, message=FALSE---------------------------------------
library(wellber)
data_object = load.wellber()
head(data_object)

## ---- warning=FALSE, message=FALSE---------------------------------------
data_object = load.wellber()
subset_data = selector(data_object, country = 'Chile', qual_ind = 'Housing expenditure', samp_type = 'Total', wind_size = 'Small')
subset_data

## ---- eval=FALSE---------------------------------------------------------
#  data_object = load.wellber()
#  subset_data = selector(data_object, country = 'Chile', qual_ind = 'Housing expenditure', samp_type = 'Total', wind_size = 'Small')
#  plot(subset_data, ind_class = 0)
#  plot(subset_data, ind_class = 1)

## ---- echo=FALSE, out.width = "750px"------------------------------------
knitr::include_graphics("/Users/jvard/Documents/MSc Data Analytics/Year_3/Adv Data Prog with R (STAT40830)/Wk_11/wellber/vignettes/wellber_plots.png")

